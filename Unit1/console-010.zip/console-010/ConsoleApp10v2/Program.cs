﻿namespace ConsoleApp10v2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World! v2");
        }
    }
}
