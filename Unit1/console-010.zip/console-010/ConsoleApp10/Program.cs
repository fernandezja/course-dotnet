﻿using System;

// See https://aka.ms/new-console-template for more information
  Console.WriteLine("Hello, World! 1");
Console.WriteLine("Hello, World .NET! 2");
