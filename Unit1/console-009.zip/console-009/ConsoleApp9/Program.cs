﻿// See https://aka.ms/new-console-template for more information
/*
 Multiple lineas de comentarios
 */
string name = "C#";
int year = 2024;

Console.WriteLine($"Hello, World! {name} {year}");
