﻿namespace ConsoleApp9v2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string name = "C#";
            int year = 2024;

            Console.WriteLine($"Hello, World! {name} {year}");
        }
    }
}
